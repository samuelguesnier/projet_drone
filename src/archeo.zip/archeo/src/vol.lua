l=require("/home/drone/catkin_ws/src/archeo/src/jakopter")
print('hello from string:'..l.altitude())

